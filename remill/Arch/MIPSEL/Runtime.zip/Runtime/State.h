/*
 * Copyright (c) 2017 Trail of Bits, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#pragma once

#pragma clang diagnostic push
#pragma clang diagnostic fatal "-Wpadded"

#include "remill/Arch/Runtime/State.h"
#include "remill/Arch/Runtime/Types.h"

struct Reg final {
  uint32_t word;
}__attribute__((packed));

static_assert(sizeof(uint32_t) == sizeof(Reg), "Invalid packing of `Reg`.");

static_assert(0 == __builtin_offsetof(Reg, word),
               "Invalid packing of `Reg::word`.");

struct FReg final {                                                      // check added for floating point register
  float32_t word;
}__attribute__((packed));

static_assert(sizeof(float32_t) == sizeof(FReg), "Invalid packing of `FReg`.");

static_assert(0 == __builtin_offsetof(FReg, word),
               "Invalid packing of `FReg::word`.");

struct DReg final {
  uint64_t dword;
}__attribute__((packed));

static_assert(sizeof(uint64_t) == sizeof(DReg), "Invalid packing of `Reg`.");

static_assert(0 == __builtin_offsetof(DReg, dword),
               "Invalid packing of `Reg::word`.");

struct FPReg final {
  float32_t word; /* single precision float */

  // double precision requires using pairs of
  // single precision, even numbered regs.
  // odd numbered regs are included automatically
}__attribute__((packed));

static_assert(sizeof(float32_t) == sizeof(FPReg), "Invalid packing of `Reg`.");
//add some checks for this

// do we need alignment here?
struct  CP1 final { // floating point Co-Processor 1
  //volatile uint32_t _0;
  union {
    float64_t DReg; /* double precision uses two regs together*/
    struct  {
      FPReg f0; /* for single precision */
      FPReg f1; /* for single precision*/
    };
  }D0;
  //volatile uint32_t _1;
  union {
    float64_t DReg;
    struct  {
      FPReg f2;
      FPReg f3;
    };
  }D2;
//volatile uint32_t _2;
  union {
    float64_t DReg;
    struct  {
      FPReg f4;
      FPReg f5;
    };
  }D4;
  //volatile uint32_t _3;
  union {
    float64_t DReg;
    struct  {
      FPReg f6;
      FPReg f7;
    };
  }D6;
//volatile uint32_t _4;
  union {
    float64_t DReg;
    struct  {
      FPReg f8;
      FPReg f9;
    };
  }D8;
//volatile uint32_t _5;
  union {
    float64_t DReg;
    struct  {
      FPReg f10;
      FPReg f11;
    };
  }D10;
//volatile uint32_t _6;
  union {
    float64_t DReg;
    struct  {
      FPReg f12;
      FPReg f13;
    };
  }D12;
//volatile uint32_t _7;
  union {
    float64_t DReg;
    struct  {
      FPReg f14;
      FPReg f15;
    };
  }D14;
//volatile uint32_t _8;
  union {
    float64_t DReg;
    struct  {
      FPReg f16;
      FPReg f17;
    };
  }D16;
//volatile uint32_t _9;
  union {
    float64_t DReg;
    struct  {
      FPReg f18;
      FPReg f19;
    };
  }D18;
//volatile uint32_t _10;
  union {
    float64_t DReg;
    struct  {
      FPReg f20;
      FPReg f21;
    };
  }D20;
//volatile uint32_t _11;
  union {
    float64_t DReg;
    struct  {
      FPReg f22;
      FPReg f23;
    };
  }D22;
//volatile uint32_t _12;
  union {
    float64_t DReg;
    struct  {
      FPReg f24;
      FPReg f25;
    };
  }D24;
//volatile uint32_t _13;
  union {
    float64_t DReg;
    struct  {
      FPReg f26;
      FPReg f27;
    };
  }D26;
//volatile uint32_t _14;
  union {
    float64_t DReg;
    struct  {
      FPReg f28;
      FPReg f29;
    };
  }D28;
//volatile uint32_t _15;
  union {
    float64_t DReg;
    struct  {
      FPReg f30;
      FPReg f31;
    };
  }D30;
  // float64_t cc; /* floating point compare condition code */
  // bool cc;
}__attribute__((packed));

// static_assert(128 == sizeof(CP1), "Invalid structure packing of `CP1`."); /* without //volatile */
// static_assert(?? == sizeof(CP1), "Invalid structure packing of `CP1`."); /* with //volatile */


// union FCSR final { /* alignment needed ? */
//   // FLoating Point control and Status Register
//   // CP1 Control Reg 31
//   // must this go inside struct FP1?
//   uint32_t flat;
//   struct {
//     uint32_t RM: 2; // Rounding Mode
//     //Flags
//     uint32_t FI: 1;
//     uint32_t FU: 1;
//     uint32_t FO: 1;
//     uint32_t FZ: 1;
//     uint32_t FV: 1;
//     // Enables
//     uint32_t EI: 1;
//     uint32_t EU: 1;
//     uint32_t EO: 1;
//     uint32_t EZ: 1;
//     uint32_t EV: 1;
//     // Cause
//     uint32_t CI: 1; // Inexact
//     uint32_t CU: 1; // UnderFlow
//     uint32_t CO: 1; // Overflow
//     uint32_t CZ: 1; // Divide by Zero
//     uint32_t CV: 1; // Invalid Operation
//     uint32_t CE: 1; // Unimplemented Operation [only for Cause bits]
//     uint32_t nan: 1; // NaN encoding
//     uint32_t abs: 1; // ABS encoding
//     uint32_t reserved: 1; // Reserved
//     uint32_t Impl: 2; // Implementation dependent
//     uint32_t _0: 1; // FCC bit 0
//     uint32_t FS: 1; // Flush to Zero
//     // FCC bits
//     uint32_t _1: 1;
//     uint32_t _2: 1;
//     uint32_t _3: 1;
//     uint32_t _4: 1;
//     uint32_t _5: 1;
//     uint32_t _6: 1;
//     uint32_t _7: 1;
//   }__attribute__((packed));
// }__attribute__((packed));

struct CP2 final {

//volatile uint32_t _0; // mips registers added
  DReg zero; //always equal to zero
  //volatile uint32_t _1;              // changes added
  DReg at; // assembler temporary, used by the assembler
  //volatile uint32_t _2;
  DReg v0; //return value from a function call
  //volatile uint32_t _3;
  DReg v1; //return value from a function call
  //volatile uint32_t _4;
  DReg a0; // first four parameters of a function call
  //volatile uint32_t _5;
  DReg a1; // first four parameters of a function call
  //volatile uint32_t _6;
  DReg a2; // first four parameters of a function call
  //volatile uint32_t _7;
  DReg a3; // first four parameters of a function call
  //volatile uint32_t _8;
  DReg t0; // Temp Vars, need not be preserved
  //volatile uint32_t _9;
  DReg t1; // Temp Vars, need not be preserved
  //volatile uint32_t _10;
  DReg t2; // Temp Vars, need not be preserved
  //volatile uint32_t _11;
  DReg t3; // Temp Vars, need not be preserved
  //volatile uint32_t _12;
  DReg t4; // Temp Vars, need not be preserved
  //volatile uint32_t _13;
  DReg t5; // Temp Vars, need not be preserved
  //volatile uint32_t _14;
  DReg t6; // Temp Vars, need not be preserved
  //volatile uint32_t _15;
  DReg t7; // Temp Vars, need not be preserved
  //volatile uint32_t _16;
  DReg s0; //Function variables, must be preserved
  //volatile uint32_t _17;
  DReg s1; //Function variables, must be preserved
  //volatile uint32_t _18;
  DReg s2; //Function variables, must be preserved
  //volatile uint32_t _19;
  DReg s3; //Function variables, must be preserved
  //volatile uint32_t _20;
  DReg s4; //Function variables, must be preserved
  //volatile uint32_t _21;
  DReg s5; //Function variables, must be preserved
  //volatile uint32_t _22;
  DReg s6; //Function variables, must be preserved
  //volatile uint32_t _23;
  DReg s7; //Function variables, must be preserved
  //volatile uint32_t _24;
  DReg t8; //Two more temporary variables
  //volatile uint32_t _25;
  DReg t9; //Two more temporary variables
  //volatile uint32_t _26;
  DReg k0; // Kernel use regs, may change unexpectedly
  //volatile uint32_t _27;
  DReg k1; // Kernel use regs, may change unexpectedly
  //volatile uint32_t _28;
  DReg gp; // global pointer
  //volatile uint32_t _29;
  DReg sp; // Stack pointer
  //volatile uint32_t _30;
  DReg fp; //or s8. Stack frame pointer or subroutine variable.
  //volatile uint32_t _31;                                                                          
  DReg ra;  // return address of the last subroutine call.
  //volatile uint32_t _32;                                                                           
  DReg pc;  // Program counter of the CURRENT instruction!

}__attribute__((packed));


struct alignas(4) GPR final {          // coprocessor 0 registers 

  //volatile uint32_t _0; // mips registers added
  Reg zero; //always equal to zero
  //volatile uint32_t _1;              // changes added
  Reg at; // assembler temporary, used by the assembler
  //volatile uint32_t _2;
  Reg v0; //return value from a function call
  //volatile uint32_t _3;
  Reg v1; //return value from a function call
  //volatile uint32_t _4;
  Reg a0; // first four parameters of a function call
  //volatile uint32_t _5;
  Reg a1; // first four parameters of a function call
  //volatile uint32_t _6;
  Reg a2; // first four parameters of a function call
  //volatile uint32_t _7;
  Reg a3; // first four parameters of a function call
  //volatile uint32_t _8;
  Reg t0; // Temp Vars, need not be preserved
  //volatile uint32_t _9;
  Reg t1; // Temp Vars, need not be preserved
  //volatile uint32_t _10;
  Reg t2; // Temp Vars, need not be preserved
  //volatile uint32_t _11;
  Reg t3; // Temp Vars, need not be preserved
  //volatile uint32_t _12;
  Reg t4; // Temp Vars, need not be preserved
  //volatile uint32_t _13;
  Reg t5; // Temp Vars, need not be preserved
  //volatile uint32_t _14;
  Reg t6; // Temp Vars, need not be preserved
  //volatile uint32_t _15;
  Reg t7; // Temp Vars, need not be preserved
  //volatile uint32_t _16;
  Reg s0; //Function variables, must be preserved
  //volatile uint32_t _17;
  Reg s1; //Function variables, must be preserved
  //volatile uint32_t _18;
  Reg s2; //Function variables, must be preserved
  //volatile uint32_t _19;
  Reg s3; //Function variables, must be preserved
  //volatile uint32_t _20;
  Reg s4; //Function variables, must be preserved
  //volatile uint32_t _21;
  Reg s5; //Function variables, must be preserved
  //volatile uint32_t _22;
  Reg s6; //Function variables, must be preserved
  //volatile uint32_t _23;
  Reg s7; //Function variables, must be preserved
  //volatile uint32_t _24;
  Reg t8; //Two more temporary variables
  //volatile uint32_t _25;
  Reg t9; //Two more temporary variables
  //volatile uint32_t _26;
  Reg k0; // Kernel use regs, may change unexpectedly
  //volatile uint32_t _27;
  Reg k1; // Kernel use regs, may change unexpectedly
  //volatile uint32_t _28;
  Reg gp; // global pointer
  //volatile uint32_t _29;
  Reg sp; // Stack pointer
  //volatile uint32_t _30;
  Reg fp; //or s8. Stack frame pointer or subroutine variable.
  //volatile uint32_t _31;                                                                            // upto this point
  Reg ra;  // return address of the last subroutine call.
  //volatile uint32_t _32;                                                                            // not added for mips
  Reg pc;  // Program counter of the CURRENT instruction!
  // Reg HI;
  // Reg LO;

}__attribute__((packed));

struct alignas(4) FPR final {          // coprocessor 1 floating point registers 

  
  FReg f0; 
  
  FReg f1; 
  
  FReg f2; 
  
  FReg f3; 

  FReg f4; 
  
  FReg f5; 
  
  FReg f6; 
 
  FReg f7; 
  
  FReg f8; 
  
  FReg f9; 
  
  FReg f10;
 
  FReg f11; 
  
  FReg f12; 
  
  FReg f13; 
  
  FReg f14; 
  
  FReg f15; 
  
  FReg f16; 
  
  FReg f17;
  
  FReg f18; 
 
  FReg f19; 
  
  FReg f20; 
  
  FReg f21; 
  
  FReg f22; 
  
  FReg f23; 
  
  FReg f24; 
  
  FReg f25;
  
  FReg f26; 
  
  FReg f27; 
 
  FReg f28; 
  
  FReg f29;
  
  FReg f30; 
                                                                         
  FReg f31;  
  

}__attribute__((packed));


// static_assert(264 == sizeof(GPR), "Invalid structure packing of `GPR`."); /* with //volatile */
// static_assert(132 == sizeof(GPR), "Invalid structure packing of `GPR`."); /* without //volatile */

struct alignas(4) SPR final {
  //volatile uint32_t _0;
  Reg HI;
  //volatile uint32_t _1;
  Reg LO;
}__attribute__((packed));

struct alignas(4) HINT {                      // Hint field for prefetch instruction

   uint32_t load:1;
   uint32_t store:1;
   uint32_t reserved:2;
   uint32_t load_streamed:1;
   uint32_t store_streamed:1;
   uint32_t load_retained:1;
   uint32_t store_retained:1;
   uint32_t reserved_1:13;
   uint32_t implementation_dependent:4;
   uint32_t writeback_invalidate:1;
   uint32_t implementation_dependent_1:4;
   uint32_t prepareforstore:1;
   uint32_t implementation_dependent_2:1;
}__attribute__((packed));

struct alignas(4) FCC
{
   uint32_t cc;
   // bool cc;
}__attribute__((packed));

struct alignas(4) COP2CC               // coprocessor 2 condition code 
{
   uint32_t cc;
   // bool cc;
}__attribute__((packed));

struct alignas(4) COP2CR              // coprocessor 2 control register  
{
   uint32_t cr;
   // bool cc;
}__attribute__((packed));

struct alignas(4) COP2GR               // coprocessor 2 general register(32 bit)
{
   uint32_t gr;
   // bool cc;
}__attribute__((packed));


// static_assert(16 == sizeof(SPR), "Invalid structure packing of `SPR`."); /* with //volatile */
static_assert(8 == sizeof(SPR), "Invalid structure packing of `SPR`."); /* without //volatile */


struct alignas(16) State final : public ArchState { // ArchState is aligned to 16

  CP1 cp1;  // ?? bytes. | 128 bytes
  // uint64_t _0;

  
  GPR gpr;  // 264 bytes. | 132 bytes
  // uint64_t _1;

  FPR fpr;  
  // uint64_t _1;

  SPR spr;
  // bool cc;
  // uint32_t _2;
    
  CP2 cp2;                         // coprocessor 2  
  uint32_t _1;
  uint32_t _2; 

  COP2CR cop2cr;
  uint32_t _3;
  uint32_t _4;
  uint32_t _5;

  COP2GR cop2gr;
  uint32_t _6;
  uint32_t _7;
  uint32_t _8;

  COP2CC cop2cc;               // COP2 condition code
  uint32_t _9;
  uint32_t _10;
  uint32_t _11;

  HINT hint;                 // Hint field for prefetch instruction
  uint32_t _12;
  uint32_t _13;
  uint32_t _14;

  FCC fcc;
  uint64_t _15; //alignment
  uint32_t _16; //alignment
  // uint32_t _3;
  uint32_t TLS_BASE;    
    
  // FCSR fcsr;
  // uint32_t _4;
  // uint64_t _5;

}__attribute__((packed));

// static_assert((248 + 264 + 16) == sizeof(State),
//               "Invalid packing of `struct State`"); /* with  //volatile  || need to update for FCSR */ 
// static_assert((?? + 132 + 16) == sizeof(State),
//               "Invalid packing of `struct State`"); /* without //volatile || need to update for FCSR*/

using MIPSELState = State;

#pragma clang diagnostic pop
