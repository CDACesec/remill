CMAKE_GENERATOR
---------------

The generator used to build the project.  See :manual:`cmake-generators(7)`.

The name of the generator that is being used to generate the build
files.  (e.g.  ``Unix Makefiles``, ``Ninja``, etc.)
