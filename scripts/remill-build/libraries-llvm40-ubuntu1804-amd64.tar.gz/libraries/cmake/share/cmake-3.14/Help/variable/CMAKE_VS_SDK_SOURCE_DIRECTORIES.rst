CMAKE_VS_SDK_SOURCE_DIRECTORIES
-------------------------------

This variable allows to override Visual Studio default Source Directories.
