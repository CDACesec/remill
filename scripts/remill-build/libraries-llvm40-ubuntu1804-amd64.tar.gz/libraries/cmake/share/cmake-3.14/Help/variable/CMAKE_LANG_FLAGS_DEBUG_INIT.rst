CMAKE_<LANG>_FLAGS_DEBUG_INIT
-----------------------------

This variable is the ``Debug`` variant of the
:variable:`CMAKE_<LANG>_FLAGS_<CONFIG>_INIT` variable.
