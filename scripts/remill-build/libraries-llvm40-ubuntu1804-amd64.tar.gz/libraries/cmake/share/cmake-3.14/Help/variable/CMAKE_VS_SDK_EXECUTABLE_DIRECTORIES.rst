CMAKE_VS_SDK_EXECUTABLE_DIRECTORIES
-----------------------------------

This variable allows to override Visual Studio default Executable Directories.
