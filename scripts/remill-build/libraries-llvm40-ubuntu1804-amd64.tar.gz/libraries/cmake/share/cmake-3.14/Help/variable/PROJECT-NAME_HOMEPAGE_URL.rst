<PROJECT-NAME>_HOMEPAGE_URL
---------------------------

Value given to the ``HOMEPAGE_URL`` option of the most recent call to the
:command:`project` command with project name ``<PROJECT-NAME>``, if any.
