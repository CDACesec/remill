CTEST_DROP_SITE
---------------

Specify the CTest ``DropSite`` setting
in a :manual:`ctest(1)` dashboard client script.
