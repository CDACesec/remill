CTEST_TRIGGER_SITE
------------------

Legacy option.  Not used.
