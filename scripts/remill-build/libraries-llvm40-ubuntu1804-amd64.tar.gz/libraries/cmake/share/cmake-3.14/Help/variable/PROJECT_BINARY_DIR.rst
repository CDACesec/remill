PROJECT_BINARY_DIR
------------------

Full path to build directory for project.

This is the binary directory of the most recent :command:`project` command.
