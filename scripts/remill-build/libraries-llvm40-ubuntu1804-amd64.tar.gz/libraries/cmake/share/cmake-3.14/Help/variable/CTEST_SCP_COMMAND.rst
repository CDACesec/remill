CTEST_SCP_COMMAND
-----------------

Legacy option.  Not used.
