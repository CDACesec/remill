CMAKE_CPACK_COMMAND
-------------------

Full path to :manual:`cpack(1)` command installed with CMake.

This is the full path to the CPack executable :manual:`cpack(1)` which is
useful from custom commands that want to use the :manual:`cmake(1)` ``-E``
option for portable system commands.
