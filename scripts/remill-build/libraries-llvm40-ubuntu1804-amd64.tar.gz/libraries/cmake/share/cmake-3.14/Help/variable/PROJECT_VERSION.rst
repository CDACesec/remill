PROJECT_VERSION
---------------

Value given to the ``VERSION`` option of the most recent call to the
:command:`project` command, if any.

See also the component-wise version variables
:variable:`PROJECT_VERSION_MAJOR`,
:variable:`PROJECT_VERSION_MINOR`,
:variable:`PROJECT_VERSION_PATCH`, and
:variable:`PROJECT_VERSION_TWEAK`.
