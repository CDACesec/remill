CMAKE_MODULE_PATH
-----------------

:ref:`Semicolon-separated list <CMake Language Lists>` of directories specifying a search path
for CMake modules to be loaded by the :command:`include` or
:command:`find_package` commands before checking the default modules that come
with CMake.  By default it is empty, it is intended to be set by the project.
