CTEST_TEST_TIMEOUT
------------------

Specify the CTest ``TimeOut`` setting
in a :manual:`ctest(1)` dashboard client script.
