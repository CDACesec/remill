CTEST_UPDATE_OPTIONS
--------------------

Specify the CTest ``UpdateOptions`` setting
in a :manual:`ctest(1)` dashboard client script.
