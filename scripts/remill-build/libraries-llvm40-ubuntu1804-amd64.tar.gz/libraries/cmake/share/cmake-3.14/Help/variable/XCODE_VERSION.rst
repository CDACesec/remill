XCODE_VERSION
-------------

Version of Xcode (:generator:`Xcode` generator only).

Under the Xcode generator, this is the version of Xcode as specified
in ``Xcode.app/Contents/version.plist`` (such as ``3.1.2``).
