MSYS
----

``True`` when using the :generator:`MSYS Makefiles` generator.
