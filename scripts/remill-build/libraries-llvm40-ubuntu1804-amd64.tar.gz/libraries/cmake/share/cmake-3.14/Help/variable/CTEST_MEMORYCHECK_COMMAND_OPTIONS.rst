CTEST_MEMORYCHECK_COMMAND_OPTIONS
---------------------------------

Specify the CTest ``MemoryCheckCommandOptions`` setting
in a :manual:`ctest(1)` dashboard client script.
