CMAKE_Fortran_FORMAT
--------------------

Set to ``FIXED`` or ``FREE`` to indicate the Fortran source layout.

This variable is used to initialize the :prop_tgt:`Fortran_FORMAT` property on
all the targets.  See that target property for additional information.
